using UnityEngine;
using System;

namespace Tracking4All
{
    /// <summary>
    /// Provides pose landmarks from UDP data, bypassing MediaPipe.
    /// This acts as a direct landmark provider that puppets can consume.
    /// </summary>
    public class UDPPoseLandmarkProvider : MonoBehaviour, ILandmarkProvider<PoseLandmarks>
    {
        [Header("UDP Configuration")]
        [SerializeField] public int listenPort = 52733;
        
        [Header("Status")]
        [SerializeField] private bool isReceivingData = false;
        [SerializeField] private float lastUpdateTime = 0f;
        
        // Landmark storage
        private Landmark[] landmarks = new Landmark[33];
        
        // UDP Server component
        private UDPPoseServer udpServer;
        
        // Internal lifecycle manager
        private SimpleLifecycleManager lifecycleManager;
        
        // Events from ILandmarkProvider
        public event GroupEvent OnLandmarksUpdated
        {
            add { if (lifecycleManager != null) lifecycleManager.OnUpdated += value; }
            remove { if (lifecycleManager != null) lifecycleManager.OnUpdated -= value; }
        }
        
        public event GroupEvent OnLandmarksReady
        {
            add { if (lifecycleManager != null) lifecycleManager.OnReady += value; }
            remove { if (lifecycleManager != null) lifecycleManager.OnReady -= value; }
        }
        
        public event GroupEvent OnLandmarksDisposed
        {
            add { if (lifecycleManager != null) lifecycleManager.OnDisposed += value; }
            remove { if (lifecycleManager != null) lifecycleManager.OnDisposed -= value; }
        }
        
        public event GroupEvent OnLandmarksResumed
        {
            add { if (lifecycleManager != null) lifecycleManager.OnResumed += value; }
            remove { if (lifecycleManager != null) lifecycleManager.OnResumed -= value; }
        }
        
        public event GroupEvent OnLandmarksTimedOut
        {
            add { if (lifecycleManager != null) lifecycleManager.OnTimedOut += value; }
            remove { if (lifecycleManager != null) lifecycleManager.OnTimedOut -= value; }
        }
        
        public IProviderLifecycle Lifecycle => lifecycleManager;
        public int GroupSize => 1;
        public int DataCount => 33;
        
        private void Awake()
        {
            // Initialize lifecycle manager
            lifecycleManager = new SimpleLifecycleManager(1);
            
            // Initialize all landmarks
            for (int i = 0; i < 33; i++)
            {
                landmarks[i] = new Landmark();
            }
            
            // Get or add UDP server component
            udpServer = GetComponent<UDPPoseServer>();
            if (udpServer == null)
            {
                udpServer = gameObject.AddComponent<UDPPoseServer>();
            }
        }
        
        private void Start()
        {
            // Subscribe to UDP server events
            if (udpServer != null)
            {
                udpServer.OnPoseDataReceived += HandlePoseDataReceived;
            }
            
            UnityEngine.Debug.Log($"[UDPPoseLandmarkProvider] Waiting for UDP data from Device 2...");
            // Don't signal ready yet - wait for UDP data to arrive!
        }
        
        private void CheckConnection()
        {
            var subscriberCount = lifecycleManager.GetSubscriberCount();
            if (subscriberCount == 0)
            {
                UnityEngine.Debug.LogWarning("[UDPPoseLandmarkProvider] ⚠️ No subscribers! Puppet may not be connected properly.");
                UnityEngine.Debug.LogWarning("[UDPPoseLandmarkProvider] Try disabling and re-enabling the Puppet-StandardT-Remy GameObject.");
            }
            else
            {
                UnityEngine.Debug.Log($"[UDPPoseLandmarkProvider] ✅ {subscriberCount} subscriber(s) connected!");
            }
        }
        
        private void HandlePoseDataReceived(PoseData poseData)
        {
            if (poseData == null || poseData.worldLandmarks == null) return;
            
            // Update landmarks
            for (int i = 0; i < 33 && i < poseData.worldLandmarks.Length; i++)
            {
                landmarks[i].Position = poseData.worldLandmarks[i];
            }
            
            // Update status
            bool wasFirstData = !isReceivingData;
            isReceivingData = true;
            lastUpdateTime = Time.time;
            
            // On first data received, schedule the ready signal
            //if (wasFirstData && !hasSignaledReady)
            //{
            //    UnityEngine.Debug.Log($"[UDPPoseLandmarkProvider] 📦 First UDP data received! Will signal ready in {delayAfterFirstData}s...");
            //    Invoke(nameof(SignalReady), delayAfterFirstData);
            //}
            
            //// Only notify subscribers after we've signaled ready
            //if (hasSignaledReady)
            //{
            //    // Debug: Check subscriber count periodically
            //    if (Time.frameCount % 120 == 0) // Every ~2 seconds
            //    {
                    //var subscriberCount = lifecycleManager.GetSubscriberCount();
                    //if (subscriberCount == 0)
                    //{
                    //    UnityEngine.Debug.LogWarning($"[UDPPoseLandmarkProvider] ⚠️ No subscribers listening!");
                    //}
                //}
                
                // Notify all subscribers that new data is available
                lifecycleManager.NotifyUpdated(0);
            //}
        }
        
        //private void SignalReady()
        //{
        //    if (hasSignaledReady) return;
            
        //    hasSignaledReady = true;
        //    lifecycleManager.SetReady(0);
            
        //    UnityEngine.Debug.Log("[UDPPoseLandmarkProvider] ✅ Ready! Puppet should now subscribe and Remy should start moving!");
            
        //    // Check connection after a moment
        //    Invoke(nameof(CheckConnection), 1f);
        //}
        
        public Landmark Get(int group, PoseLandmarks index)
        {
            if (group != 0)
            {
                UnityEngine.Debug.LogWarning($"[UDPPoseLandmarkProvider] Invalid group {group}, only group 0 is supported");
                return new Landmark();
            }
            
            int idx = (int)index;
            if (idx < 0 || idx >= 33)
            {
                UnityEngine.Debug.LogWarning($"[UDPPoseLandmarkProvider] Invalid landmark index {idx}");
                return new Landmark();
            }
            
            return landmarks[idx];
        }
        
        public Landmark Get(int group, int index)
        {
            return Get(group, (PoseLandmarks)index);
        }
        
        private void OnDestroy()
        {
            if (udpServer != null)
            {
                udpServer.OnPoseDataReceived -= HandlePoseDataReceived;
            }
            
            lifecycleManager?.SetDisposed(0);
        }
    }
    
    /// <summary>
    /// Simple lifecycle manager for providers that don't use adapters
    /// </summary>
    internal class SimpleLifecycleManager : IProviderLifecycle
    {
        private bool[] isReady;
        
        public event GroupEvent OnReady;
        public event GroupEvent OnDisposed;
        public event GroupEvent OnResumed;
        public event GroupEvent OnUpdated;
        public event GroupEvent OnTimedOut;
        
        public int GroupSize { get; private set; }
        
        public SimpleLifecycleManager(int groupSize)
        {
            GroupSize = groupSize;
            isReady = new bool[groupSize];
        }
        
        public void SetReady(int group)
        {
            if (!isReady[group])
            {
                isReady[group] = true;
                OnReady?.Invoke(group);
            }
        }
        
        public void SetDisposed(int group)
        {
            if (isReady[group])
            {
                isReady[group] = false;
                OnDisposed?.Invoke(group);
            }
        }
        
        public void NotifyUpdated(int group)
        {
            OnUpdated?.Invoke(group);
        }
        
        public int GetSubscriberCount()
        {
            return OnUpdated?.GetInvocationList()?.Length ?? 0;
        }
        
        public bool IsReady(int group) => group >= 0 && group < GroupSize && isReady[group];
        public bool IsDisposed(int group) => !IsReady(group);
        public bool IsAlive(int group) => IsReady(group);
        public bool IsTimedOut(int group) => !IsAlive(group);
    }
}
