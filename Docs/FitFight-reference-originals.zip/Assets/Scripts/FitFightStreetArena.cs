using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

/// <summary>Reference-inspired court, built as three combined meshes for mobile rendering.</summary>
public sealed class FitFightStreetArena : MonoBehaviour
{
    private readonly List<Material> materials = new List<Material>();
    private readonly List<Mesh> meshes = new List<Mesh>();
    private readonly List<Renderer> hiddenRenderers = new List<Renderer>();
    private readonly List<Light> hiddenLights = new List<Light>();
    private AmbientMode previousAmbient;
    private Color previousSky, previousEquator, previousGround;
    private bool initialized;

    public void Build(Transform first, Transform second)
    {
        if (initialized) return;
        Material template = Resources.Load<Material>("FitFightStreet");
        if (template == null) { Debug.LogError("FitFightStreet material is missing."); return; }
        initialized = true;
        var a = FitFightArenaCamera.FighterBounds(first, first.GetComponentsInChildren<SkinnedMeshRenderer>(true));
        var b = FitFightArenaCamera.FighterBounds(second, second.GetComponentsInChildren<SkinnedMeshRenderer>(true));
        float unit = Mathf.Max(.5f, Mathf.Max(a.size.y, b.size.y)) / 2f;
        Vector3 midpoint = (a.center + b.center) * .5f;
        transform.position = new Vector3(midpoint.x, Mathf.Min(a.min.y, b.min.y) - .015f * unit, midpoint.z);
        transform.localScale = Vector3.one * unit;

        // Hide only authored scenery renderers; preserve colliders and gameplay objects.
        foreach (string name in new[] { "Environment", "Plane" })
        {
            GameObject scenery = GameObject.Find(name);
            if (scenery == null) continue;
            foreach (var renderer in scenery.GetComponentsInChildren<Renderer>())
            {
                if (!renderer.enabled || renderer is SkinnedMeshRenderer
                    || renderer.transform.IsChildOf(first) || renderer.transform.IsChildOf(second)) continue;
                hiddenRenderers.Add(renderer);
                renderer.enabled = false;
            }
        }

        var cubeObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
        Mesh cube = cubeObject.GetComponent<MeshFilter>().sharedMesh;
        cubeObject.SetActive(false);
        var paving = new List<CombineInstance>();
        var metal = new List<CombineInstance>();
        var lines = new List<CombineInstance>();
        Add(paving, cube, new Vector3(0, -.12f, 0), new Vector3(80, .24f, 80));
        // Expansion joints give the floor scale without a large texture allocation.
        for (int i = -24; i <= 24; i++)
        {
            Add(lines, cube, new Vector3(i * 1.2f, .002f, 0), new Vector3(.016f, .006f, 58));
            Add(lines, cube, new Vector3(0, .002f, i * 1.2f), new Vector3(58, .006f, .016f));
        }
        // Open court: fence surrounds both player viewpoints while leaving the fight unobstructed.
        for (int side = 0; side < 4; side++)
        {
            Quaternion turn = Quaternion.Euler(0, side * 90, 0);
            for (int post = -5; post <= 5; post++)
                Add(metal, cube, turn * new Vector3(post * 3, 1.65f, 15), new Vector3(.09f, 3.3f, .09f));
            for (int rail = 0; rail < 3; rail++)
                Add(metal, cube, turn * new Vector3(0, .3f + rail * 1.35f, 15), new Vector3(30, .065f, .065f), turn);
            for (int wire = -59; wire <= 59; wire++)
                Add(metal, cube, turn * new Vector3(wire * .25f, 1.65f, 15), new Vector3(.012f, 2.7f, .012f));
            for (int wire = 1; wire <= 10; wire++)
                Add(metal, cube, turn * new Vector3(0, .3f + wire * .25f, 15), new Vector3(30, .012f, .012f), turn);
        }
        Combine("Warm concrete", paving, template, new Color(.65f, .61f, .49f), true);
        Combine("Paving joints", lines, template, new Color(.30f, .32f, .29f), false);
        Combine("Steel court fence", metal, template, new Color(.12f, .21f, .21f), true);
        Destroy(cubeObject);

        foreach (var light in FindObjectsOfType<Light>())
        {
            if (light.type != LightType.Directional || !light.enabled) continue;
            hiddenLights.Add(light);
            light.enabled = false;
        }
        var sunObject = new GameObject("FitFight Afternoon Sun");
        sunObject.transform.SetParent(transform, false);
        sunObject.transform.rotation = Quaternion.Euler(48, -35, 0);
        var sun = sunObject.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.color = new Color(1f, .92f, .78f);
        sun.intensity = 1.15f;
        sun.shadows = LightShadows.Soft;
        sun.shadowStrength = .8f;
        sun.shadowBias = .04f;
        sun.shadowNormalBias = .2f;
        previousAmbient = RenderSettings.ambientMode;
        previousSky = RenderSettings.ambientSkyColor;
        previousEquator = RenderSettings.ambientEquatorColor;
        previousGround = RenderSettings.ambientGroundColor;
        RenderSettings.ambientMode = AmbientMode.Trilight;
        RenderSettings.ambientSkyColor = new Color(.52f, .67f, .72f);
        RenderSettings.ambientEquatorColor = new Color(.43f, .47f, .46f);
        RenderSettings.ambientGroundColor = new Color(.27f, .25f, .21f);
    }

    private static void Add(List<CombineInstance> list, Mesh cube, Vector3 position, Vector3 scale, Quaternion? rotation = null)
    {
        list.Add(new CombineInstance { mesh = cube, transform = Matrix4x4.TRS(position, rotation ?? Quaternion.identity, scale) });
    }

    private void Combine(string name, List<CombineInstance> parts, Material template, Color color, bool shadows)
    {
        var mesh = new Mesh { name = name };
        mesh.CombineMeshes(parts.ToArray(), true, true);
        meshes.Add(mesh);
        var material = new Material(template) { name = name, color = color };
        material.SetFloat("_Glossiness", .12f);
        material.SetFloat("_Metallic", 0);
        materials.Add(material);
        var child = new GameObject(name, typeof(MeshFilter), typeof(MeshRenderer));
        child.transform.SetParent(transform, false);
        child.GetComponent<MeshFilter>().sharedMesh = mesh;
        var renderer = child.GetComponent<MeshRenderer>();
        renderer.sharedMaterial = material;
        renderer.shadowCastingMode = shadows ? ShadowCastingMode.On : ShadowCastingMode.Off;
        renderer.receiveShadows = true;
    }

    private void OnDestroy()
    {
        foreach (var renderer in hiddenRenderers) if (renderer != null) renderer.enabled = true;
        foreach (var light in hiddenLights) if (light != null) light.enabled = true;
        foreach (var mesh in meshes) Destroy(mesh);
        foreach (var material in materials) Destroy(material);
        if (!initialized) return;
        RenderSettings.ambientMode = previousAmbient;
        RenderSettings.ambientSkyColor = previousSky;
        RenderSettings.ambientEquatorColor = previousEquator;
        RenderSettings.ambientGroundColor = previousGround;
    }
}
