using System;

internal static class FitFightFramingMath
{
    // Coordinates are relative to the look target in camera axes. Camera sits at z = -distance.
    public static float RequiredDistance(float x, float y, float z, float tanX, float tanY,
        float left, float right, float bottom, float top)
    {
        return Math.Max(Math.Abs(x) / (tanX * (x < 0 ? left : right)) - z,
            Math.Abs(y) / (tanY * (y < 0 ? bottom : top)) - z);
    }
}
