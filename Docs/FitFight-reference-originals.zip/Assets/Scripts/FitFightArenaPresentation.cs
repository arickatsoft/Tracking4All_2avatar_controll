using System.Collections;
using UnityEngine;
using UnityEngine.UI;

/// <summary>Scene-scoped presentation, configured by the existing player selector.</summary>
public sealed class FitFightArenaPresentation : MonoBehaviour
{
    private FitFightStreetArena arena;
    private GameObject hud;
    private RectTransform safeHud;
    private Text localName, remoteName;
    private Camera preview;
    private bool previewWasEnabled;
    private Rect lastSafe;
    private Vector2Int lastScreen;

    public void Configure(GameObject remy, GameObject adam, Camera main, GameObject adamRig, bool localIsAdam)
    {
        if (remy == null || adam == null) return;
        if (main != null) SetupCamera(main, remy.transform, adam.transform);
        if (adamRig != null)
            foreach (var camera in adamRig.GetComponentsInChildren<Camera>(true))
                if (camera.targetTexture == null) SetupCamera(camera, adam.transform, remy.transform);
        if (arena == null)
        {
            arena = new GameObject("FitFight Street Court").AddComponent<FitFightStreetArena>();
            StartCoroutine(BuildAfterInitialization(remy.transform, adam.transform));
            BuildHud();
            var previewObject = GameObject.Find("Preview Camera");
            if (previewObject != null)
            {
                preview = previewObject.GetComponent<Camera>();
                if (preview != null) { previewWasEnabled = preview.enabled; preview.enabled = false; }
            }
        }
        localName.text = localIsAdam ? "Adam" : "Remy";
        remoteName.text = localIsAdam ? "Remy" : "Adam";
    }

    private IEnumerator BuildAfterInitialization(Transform first, Transform second)
    {
        yield return null;
        if (arena != null && first != null && second != null) arena.Build(first, second);
    }

    private static void SetupCamera(Camera camera, Transform local, Transform remote)
    {
        var framing = camera.GetComponent<FitFightArenaCamera>();
        if (framing == null) framing = camera.gameObject.AddComponent<FitFightArenaCamera>();
        framing.Configure(local, remote);
    }

    private void BuildHud()
    {
        hud = new GameObject("FitFight Arena HUD", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
        var canvas = hud.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 20;
        var scaler = hud.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1080, 1920);
        scaler.matchWidthOrHeight = .5f;
        safeHud = MakeRect(hud.transform, "Safe HUD", Vector2.zero, Vector2.one);
        localName = Card("Local fighter", new Vector2(.025f, .89f), new Vector2(.36f, .99f), new Color(0, .74f, .37f));
        remoteName = Card("Opponent", new Vector2(.64f, .89f), new Vector2(.975f, .99f), new Color(.94f, .13f, .15f));
        UpdateSafeArea();
    }

    private Text Card(string title, Vector2 min, Vector2 max, Color accent)
    {
        var rect = MakeRect(safeHud, title, min, max);
        var background = rect.gameObject.AddComponent<FitFightRoundedPanel>();
        background.color = new Color(.16f, .23f, .23f, .91f);
        background.raycastTarget = false;
        var name = MakeRect(rect, "Name", new Vector2(.1f, .32f), new Vector2(.9f, .91f)).gameObject.AddComponent<Text>();
        name.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        name.fontSize = 45;
        name.resizeTextForBestFit = true;
        name.resizeTextMinSize = 16;
        name.resizeTextMaxSize = 45;
        name.color = Color.white;
        name.alignment = TextAnchor.MiddleLeft;
        name.raycastTarget = false;
        // Fighter identity accent, not a fabricated health meter. Match state is separate.
        var stripe = MakeRect(rect, "Fighter color", new Vector2(.1f, .15f), new Vector2(.9f, .22f)).gameObject.AddComponent<Image>();
        stripe.color = accent;
        stripe.raycastTarget = false;
        return name;
    }

    private static RectTransform MakeRect(Transform parent, string name, Vector2 min, Vector2 max)
    {
        var rect = new GameObject(name, typeof(RectTransform)).GetComponent<RectTransform>();
        rect.SetParent(parent, false);
        rect.anchorMin = min;
        rect.anchorMax = max;
        rect.offsetMin = rect.offsetMax = Vector2.zero;
        return rect;
    }

    private void Update()
    {
        if (Screen.safeArea != lastSafe || lastScreen.x != Screen.width || lastScreen.y != Screen.height)
            UpdateSafeArea();
    }

    private void UpdateSafeArea()
    {
        if (safeHud == null || Screen.width <= 0 || Screen.height <= 0) return;
        lastSafe = Screen.safeArea;
        lastScreen = new Vector2Int(Screen.width, Screen.height);
        safeHud.anchorMin = new Vector2(lastSafe.xMin / Screen.width, lastSafe.yMin / Screen.height);
        safeHud.anchorMax = new Vector2(lastSafe.xMax / Screen.width, lastSafe.yMax / Screen.height);
    }

    private void OnDestroy()
    {
        if (hud != null) Destroy(hud);
        if (arena != null) Destroy(arena.gameObject);
        if (preview != null) preview.enabled = previewWasEnabled;
    }
}
