using UnityEngine;

/// <summary>Fits both fighters inside the safe gameplay area, independently of camera-rig offsets.</summary>
[DefaultExecutionOrder(10000)]
[RequireComponent(typeof(Camera))]
public sealed class FitFightArenaCamera : MonoBehaviour
{
    private Transform localFighter, opponent;
    private Renderer[] localRenderers, opponentRenderers;
    private Camera view;
    private float distance;
    private bool snap = true;

    public void Configure(Transform local, Transform remote)
    {
        if (localFighter == local && opponent == remote) return;
        localFighter = local;
        opponent = remote;
        localRenderers = local.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        opponentRenderers = remote.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        view = GetComponent<Camera>();
        view.orthographic = false;
        view.fieldOfView = 48f;
        view.rect = new Rect(0, 0, 1, 1);
        view.clearFlags = CameraClearFlags.SolidColor;
        view.backgroundColor = new Color(.32f, .72f, .79f);
        snap = true;
    }

    public static Bounds FighterBounds(Transform fighter, Renderer[] renderers)
    {
        Bounds bounds = new Bounds(fighter.position + Vector3.up, new Vector3(1, 2, 1));
        bool found = false;
        foreach (var renderer in renderers)
        {
            if (renderer == null || !renderer.enabled || !renderer.gameObject.activeInHierarchy) continue;
            if (!found) { bounds = renderer.bounds; found = true; }
            else bounds.Encapsulate(renderer.bounds);
        }
        return bounds;
    }

    private void LateUpdate()
    {
        if (view == null || localFighter == null || opponent == null) return;
        var a = FighterBounds(localFighter, localRenderers);
        var b = FighterBounds(opponent, opponentRenderers);
        var bounds = a;
        bounds.Encapsulate(b);
        float height = Mathf.Max(Mathf.Max(a.size.y, b.size.y), .5f);
        bounds.Expand(height * .14f);
        Vector3 heading = Vector3.ProjectOnPlane(opponent.position - localFighter.position, Vector3.up);
        if (heading.sqrMagnitude < .001f) heading = Vector3.forward;
        // Offset the view sideways so the near fighter does not hide the opponent.
        heading = Quaternion.AngleAxis(-18f, Vector3.up) * heading.normalized;
        Quaternion rotation = Quaternion.LookRotation(heading, Vector3.up) * Quaternion.Euler(7f, 0, 0);
        Quaternion inverse = Quaternion.Inverse(rotation);
        float tanY = Mathf.Tan(view.fieldOfView * .5f * Mathf.Deg2Rad);
        float tanX = tanY * view.aspect;
        Rect safe = Screen.safeArea;
        float width = Mathf.Max(1, Screen.width), screenHeight = Mathf.Max(1, Screen.height);
        float left = Mathf.Max(.1f, 1 - 2 * (safe.xMin / width + .045f));
        float right = Mathf.Max(.1f, 2 * (safe.xMax / width - .045f) - 1);
        float bottom = Mathf.Max(.1f, 1 - 2 * (safe.yMin / screenHeight + .045f));
        // Reserve the top 14% of the safe screen for the fighter panels.
        float top = Mathf.Max(.1f, 2 * ((safe.yMax - safe.height * .14f) / screenHeight - .025f) - 1);
        float required = height * 1.8f;
        for (int i = 0; i < 8; i++)
        {
            Vector3 corner = bounds.center + Vector3.Scale(bounds.extents,
                new Vector3((i & 1) == 0 ? -1 : 1, (i & 2) == 0 ? -1 : 1, (i & 4) == 0 ? -1 : 1));
            Vector3 p = inverse * (corner - bounds.center);
            required = Mathf.Max(required, FitFightFramingMath.RequiredDistance(p.x, p.y, p.z, tanX, tanY, left, right, bottom, top));
        }
        // Widen immediately to avoid clipping; return slowly to avoid zoom pumping.
        distance = snap || required > distance ? required : Mathf.Lerp(distance, required, 1 - Mathf.Exp(-Time.unscaledDeltaTime));
        snap = false;
        view.nearClipPlane = Mathf.Max(.02f, height * .025f);
        view.farClipPlane = Mathf.Max(100, distance + height * 60);
        transform.SetPositionAndRotation(bounds.center - rotation * Vector3.forward * distance, rotation);
    }
}
